package main

import (
	"go-simple-api/controller"
	"net/http"

	"github.com/gin-gonic/gin"
)

var port = ":8080"

func main() {
	r := gin.Default()
	r.GET("/books", controller.GetAllBooks)
	r.GET("/book/:id", controller.GetBookById)
	r.POST("/book", controller.CreateBook)
	r.PATCH("/book/:id", controller.UpdateBook)
	r.DELETE("/book/:id", controller.DeleteBook)
	r.Run(port)
	http.ListenAndServe(port, nil)
}
