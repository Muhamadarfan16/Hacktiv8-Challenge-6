package model

type Book struct {
	Id        uint   `json:"id"`
	Name      string `json:"name"`
	Category  string `json:"category"`
	Publisher string `json:"publisher"`
}
