package controller

import (
	"go-simple-api/datasource"
	"go-simple-api/model"
	"go-simple-api/util"
	"net/http"
	"strconv"

	"github.com/gin-gonic/gin"
)

func GetAllBooks(c *gin.Context) {
	dataSource := datasource.DataSource{}
	util.ResponseSuccess(c, dataSource.GetAllBooks())
}

func GetBookById(c *gin.Context) {
	var err error
	dataSource := datasource.DataSource{}
	id, err := strconv.Atoi(c.Param("id"))
	if err != nil {
		util.ResponseError(c, http.StatusInternalServerError, err.Error())
		return
	}
	book, err := dataSource.GetBookById(uint(id))
	if err != nil {
		util.ResponseError(c, http.StatusBadRequest, err.Error())
		return
	}
	util.ResponseSuccess(c, book)
}

func CreateBook(c *gin.Context) {
	var newBook model.Book

	if err := c.ShouldBindJSON(&newBook); err != nil {
		util.ResponseError(c, http.StatusInternalServerError, err.Error())
		return
	}
	lastId := 0
	if len(datasource.BookData) != 0 {
		lastId = int(datasource.BookData[len(datasource.BookData)-1].Id)
	}
	newBook.Id = uint(lastId + 1)
	dataSource := datasource.DataSource{}
	dataSource.CreateBook(&newBook)
	util.ResponseSuccess(c, newBook)
}

func UpdateBook(c *gin.Context) {
	var err error
	var newBook model.Book
	dataSource := datasource.DataSource{}
	id, err := strconv.Atoi(c.Param("id"))
	if err != nil {
		util.ResponseError(c, http.StatusInternalServerError, err.Error())
		return
	}

	if err = c.ShouldBindJSON(&newBook); err != nil {
		util.ResponseError(c, http.StatusInternalServerError, err.Error())
		return
	}
	newBook.Id = uint(id)
	book, err := dataSource.UpdateBook(&newBook)
	if err != nil {
		util.ResponseError(c, http.StatusBadRequest, err.Error())
		return
	}
	util.ResponseSuccess(c, book)
}

func DeleteBook(c *gin.Context) {
	var err error
	dataSource := datasource.DataSource{}
	id, err := strconv.Atoi(c.Param("id"))
	if err != nil {
		util.ResponseError(c, http.StatusInternalServerError, err.Error())
		return
	}

	_, err = dataSource.DeleteBook(uint(id))
	if err != nil {
		util.ResponseError(c, http.StatusBadRequest, err.Error())
		return
	}
	util.ResponseSuccess(c, "success")
}
