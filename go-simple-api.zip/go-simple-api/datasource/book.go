package datasource

import (
	"errors"
	"fmt"
	"go-simple-api/model"
	"strconv"
)

var BookData = []model.Book{}

type DataSource struct{}

func (d *DataSource) GetAllBooks() []model.Book {
	return BookData
}

func (d *DataSource) GetBookById(id uint) (model.Book, error) {
	for _, book := range BookData {
		if book.Id == id {
			return book, nil
		}
	}
	return model.Book{}, errors.New(fmt.Sprintf("book with id %s not found", strconv.Itoa(int(id))))
}

func (d *DataSource) CreateBook(book *model.Book) {
	BookData = append(BookData, *book)
}

func (d *DataSource) UpdateBook(newBook *model.Book) (model.Book, error) {
	for i, book := range BookData {
		if book.Id == newBook.Id {
			BookData[i] = *newBook
			return BookData[i], nil
		}
	}
	return model.Book{}, errors.New(fmt.Sprintf("book with id %s not found", strconv.Itoa(int(newBook.Id))))
}

func (d *DataSource) DeleteBook(id uint) (model.Book, error) {
	for i, book := range BookData {
		if book.Id == id {
			BookData = append(BookData[:i], BookData[i+1:]...)
			return model.Book{}, nil
		}
	}
	return model.Book{}, errors.New(fmt.Sprintf("book with id %s not found", strconv.Itoa(int(id))))
}
